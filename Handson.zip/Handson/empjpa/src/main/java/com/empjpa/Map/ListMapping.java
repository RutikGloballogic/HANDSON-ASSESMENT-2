package com.empjpa.Map;
import com.empjpa.Emp.*;

import javax.persistence.*;



public class ListMapping{

  public static void main(String[] args) {

    EntityManagerFactory emf=Persistence.createEntityManagerFactory("Collection_Type");

    EntityManager em=emf.createEntityManager();

    em.getTransaction().begin();
    
    
    Address a1=new Address();

    a1.setE_pincode(3223);

    a1.setE_city("Jaipur");

    a1.setE_state("Rajasthan");

    Address a2=new Address();

    a2.setE_pincode(2334);

    a2.setE_city("Nagpur");

    a2.setE_state("Maharastra");
    
    Address a3=new Address();

    a3.setE_pincode(3434);

    a3.setE_city("Pune");

    a3.setE_state("Maharastra");
    
  Employee e1=new Employee();

  e1.setE_no(101);

  e1.setE_sal(1200);
  e1.setE_name("Raju");
  e1.setE_designation("Clerk");
  e1.getAddress().add(a1);
  

  Employee e2=new Employee();

  e2.setE_no(102);

  e2.setE_sal(1500);
  e2.setE_name("Rahul");
  e2.setE_designation("Manager");
  e1.getAddress().add(a2);
  
  Employee e3=new Employee();

  e3.setE_no(103);

  e3.setE_sal(1700);
  e3.setE_name("Mohan");
  e3.setE_designation("Sr. Manager");
  e1.getAddress().add(a3);
  
  em.persist(e1);
  em.persist(e2);
  em.persist(e3);

em.getTransaction().commit();

  em.close();

  emf.close();

    
  }
}